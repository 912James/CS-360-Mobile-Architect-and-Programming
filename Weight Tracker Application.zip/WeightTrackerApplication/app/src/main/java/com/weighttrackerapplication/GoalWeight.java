package com.weighttrackerapplication;


public class GoalWeight {
    int id;
    String username;
    String date;
    String weight;

    public GoalWeight() {
        super();
    }

    public GoalWeight(int i, String username,  String weight) {
        super();
        this.id = i;
        this.username = username;
        this.weight = weight;
    }

    // constructor
    public GoalWeight(String username, String weight) {
        this.username = username;
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return username;
    }

    public void setUserEmail(String user_email) {
        this.username = user_email;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
