package com.weighttrackerapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

public class AddNewWeight extends AppCompatActivity {

    String EmailHolder, DescHolder, QtyHolder;
    TextView UserEmail;
    ImageButton IncreaseQty, DecreaseQty;
    EditText WeightDescValue, WeightQtyValue;
    Button CancelButton, AddWeightButton;
    Boolean EmptyHolder;
    WeightDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);

        // Initiate buttons, textViews, and editText variables
        UserEmail = findViewById(R.id.textViewLoggedUser);
        WeightDescValue = findViewById(R.id.editTextWeightDescription);

        IncreaseQty = findViewById(R.id.weightQtyIncrease);
        DecreaseQty = findViewById(R.id.weightQtyDecrease);
        WeightQtyValue = findViewById(R.id.editTextWeight);
        CancelButton = findViewById(R.id.addCancelButton);
        AddWeightButton = findViewById(R.id.addWeightButton);
        db = new WeightDB(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email send by WeightsListActivity
        EmailHolder = intent.get().getStringExtra(HomeActivity.UserEmail);

        // Setting user email on textViewLoggedUser
        UserEmail.setText(getString(R.string.logged_user, EmailHolder));

        // Adding click listener to WeightQtyIncrease
        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = WeightQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            WeightQtyValue.setText(String.valueOf(total));
        });

        // Adding click listener to WeightQtyDecrease
        DecreaseQty.setOnClickListener(view -> {
            int input, total;
            //
            String qty = WeightQtyValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Weight is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                WeightQtyValue.setText(String.valueOf(total));
            }
        });

        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to WeightsListActivity after cancel adding Weight
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Adding click listener to addWeightButton and pass data to WeightsListActivity
        AddWeightButton.setOnClickListener(view -> InsertWeightIntoDatabase());
    }

    // Insert Weight data into database and send data to WeightsListActivity
    public void InsertWeightIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String email = EmailHolder;
            String desc = DescHolder;
            String qty = QtyHolder;

            // Inserting Weight data into database
            Weight Weight = new Weight(email, desc, qty);
            db.createWeight(Weight);

            // Display toast message after insert in table
            Toast.makeText(this,"Weight Added Successfully", Toast.LENGTH_LONG).show();

            // Close AddWeightActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Display toast message if Weight description is empty and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking Weight description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        DescHolder = WeightDescValue.getText().toString().trim();
        QtyHolder = WeightQtyValue.getText().toString().trim();

        if (DescHolder.isEmpty()) {
            WeightDescValue.requestFocus();
            EmptyHolder = true;
            message = "Weight Description is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

}
