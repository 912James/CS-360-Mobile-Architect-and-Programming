package com.weighttrackerapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

public class SetGoalWeight extends AppCompatActivity {

        String EmailHolder1, Weight;

        String DescHolder, QtyHolder;

        Activity activity;
        EditText WeightQtyValue;
        Button CancelButton, AddWeightButton;
        Boolean EmptyHolder;

       GoalWeightDB handler;


    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.target_weight_activity);
            activity = this;

            // Initiate buttons, textViews, and editText variables
            WeightQtyValue = findViewById(R.id.editTextWeight);
            CancelButton = findViewById(R.id.CancelButton);
            AddWeightButton = findViewById(R.id.SaveButton);
            handler = new GoalWeightDB(this);

            AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

            // Receiving user name
            EmailHolder1 = intent.get().getStringExtra(HomeActivity.UserEmail);

            // Adding click listener to addCancelButton
            CancelButton.setOnClickListener(view -> {
                // Going back to WeightsListActivity after cancel adding Weight
                Intent add = new Intent();
                setResult(0, add);
                this.finish();
            });

            AddWeightButton.setOnClickListener(view -> InsertWeightIntoDatabase());
        }

    @SuppressLint("Range")
    public void InsertWeightIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String email = EmailHolder1;
            String qty = QtyHolder;


            GoalWeight Weight = new GoalWeight(email,  qty);
            handler.createWeight(Weight);

            // Display toast message after insert in table
            Toast.makeText(this,"Weight Added Successfully", Toast.LENGTH_LONG).show();

            // Close AddWeightActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Display toast message if Weight description is empty and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }

    }

    // Checking Weight description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        Weight = WeightQtyValue.getText().toString().trim();

        if (Weight.isEmpty()) {
            WeightQtyValue.requestFocus();
            EmptyHolder = true;
            message = "Target Weight is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }
}