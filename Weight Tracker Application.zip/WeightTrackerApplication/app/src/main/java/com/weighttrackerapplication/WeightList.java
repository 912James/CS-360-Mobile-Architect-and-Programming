package com.weighttrackerapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
public class WeightList extends BaseAdapter {

    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Weight> weights;
    WeightDB db;

    public WeightList(Activity context, ArrayList<Weight> weights, WeightDB db) {
        this.context = context;
        this.weights = weights;
        this.db = db;
    }


    public static class ViewHolder {
        TextView textViewWeightId;
        TextView textViewUserEmail;
        TextView textViewDate;
        TextView textViewDailyWeight;
        ImageButton editBtn;
        ImageButton deleteBtn;
    }

    @SuppressLint({"InflateParams", "SetTextI18n"})
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.weight_layout, null, true);

            vh.editBtn = row.findViewById(R.id.editButton);
            vh.textViewWeightId = row.findViewById(R.id.textViewWeightId);
            vh.textViewUserEmail = row.findViewById(R.id.textViewUserEmail);
            vh.textViewDate = row.findViewById(R.id.textViewDate);
            vh.textViewDailyWeight = row.findViewById(R.id.textViewDailyWeight);
            vh.deleteBtn = row.findViewById(R.id.deleteButton);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.textViewWeightId.setText("" + weights.get(position).getId());
        vh.textViewUserEmail.setText(weights.get(position).getUserEmail());
        vh.textViewDate.setText(weights.get(position).getDate());
        vh.textViewDailyWeight.setText(weights.get(position).getWeight());


        // Check is the cell value is zero to change color and send SMS
        String value = vh.textViewDailyWeight.getText().toString().trim();
        if (value.equals("0")) {
            // Change background color and text color of item qty cell if value is zero
            vh.textViewDailyWeight.setBackgroundColor(Color.RED);
            vh.textViewDailyWeight.setTextColor(Color.WHITE);
            HomeActivity.SendSMSMessage(context.getApplicationContext());
        } else {
            // Change background color and text color of item qty cell to default
            vh.textViewDailyWeight.setBackgroundColor(Color.WHITE);
            vh.textViewDailyWeight.setTextColor(Color.BLACK);
        }

        final int positionPopup = position;

        vh.editBtn.setOnClickListener(view -> editPopup(positionPopup));

        vh.deleteBtn.setOnClickListener(view -> {
            //Integer index = (Integer) view.getTag();
            db.deleteWeight(weights.get(positionPopup));

            //items.remove(index.intValue());
            weights = (ArrayList<Weight>) db.getAllWeights();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();

            int itemsCount = db.getWeightsCount();
            TextView TotalItems = context.findViewById(R.id.textViewWeightCountLabel);
            TotalItems.setText(String.valueOf(itemsCount));
        });

        return  row;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return weights.size();
    }

    public void editPopup(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_weight_activity, context.findViewById(R.id.popup_element));

        popwindow = new PopupWindow(layout, 800, 1000, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        final EditText editDate = layout.findViewById(R.id.editTextDatePopup);
        final EditText editWeight = layout.findViewById(R.id.editTextWeightPopup);


        editDate.setText(weights.get(positionPopup).getDate());
        editWeight.setText(weights.get(positionPopup).getWeight());


        Button save = layout.findViewById(R.id.editSaveButton);
        Button cancel = layout.findViewById(R.id.editCancelButton);

        save.setOnClickListener(view -> {
            String date = editDate.getText().toString();
            String weightTotal = editWeight.getText().toString();


            Weight weight = weights.get(positionPopup);
            weight.setDate(date);
            weight.setWeight(weightTotal);


            db.updateWeight(weight);
            weights = (ArrayList<Weight>) db.getAllWeights();
            notifyDataSetChanged();

            Toast.makeText(context, "Weight Updated", Toast.LENGTH_SHORT).show();

            popwindow.dismiss();
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }

}