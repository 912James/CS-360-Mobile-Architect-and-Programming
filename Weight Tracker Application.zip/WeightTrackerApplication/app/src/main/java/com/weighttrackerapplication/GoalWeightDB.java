package com.weighttrackerapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class GoalWeightDB extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;

    public static final String DATABASE_NAME = "TargetWeights.DB";
    public static final String TABLE_NAME = "WeightsTable";

    public static final String COLUMN_0_ID = "id";
    public static final String COLUMN_1_USER_EMAIL = "Email";
    public static final String COLUMN_2_WEIGHT = "Weight";


    private static final String CREATE_WEIGHTS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_USER_EMAIL + " VARCHAR, " +
            COLUMN_2_WEIGHT + " VARCHAR" + ");";


    public GoalWeightDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_WEIGHTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public void createWeight(GoalWeight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USER_EMAIL, weight.getUserName());
        values.put(COLUMN_2_WEIGHT, weight.getWeight());


        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Read Weight from Database
   public Cursor readWeight(String weight) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] { COLUMN_0_ID, COLUMN_1_USER_EMAIL, COLUMN_2_WEIGHT}, COLUMN_2_WEIGHT + " = ?",
                new String[] { String.valueOf(weight) }, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        GoalWeight nweight = new GoalWeight(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2));

        cursor.close();

        return cursor;
    }

    // Update Weight in database
    public boolean updateWeight(int id, String email, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("weight", weight);

        db.update("WeightsTable", values, COLUMN_0_ID+ " = ?", new String[] { Integer.toString(id) }) ;
        return true;
    }

    public ArrayList<String> getAllWeights() {
        ArrayList<String> array_list = new ArrayList<String>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from WeightsTable", null );
        res.moveToFirst();

        while(!res.isAfterLast()){
            array_list.add(res.getString(res.getColumnIndexOrThrow(COLUMN_2_WEIGHT)));
            res.moveToNext();
        }
        res.close();
        return array_list;

    }


    public List<GoalWeight> getTargetWeight() {
        List<GoalWeight> weightList = new ArrayList<>();

        // Select All Query
        String selectQuery = " SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_2_WEIGHT + "=?";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        while (cursor.moveToNext()){
                GoalWeight weight = new GoalWeight();
                weight.setId(Integer.parseInt("id"));
                weight.setUserEmail("email");
                weight.setWeight("Weight");
                weightList.add(weight);
                String myText = cursor.getString(cursor.getColumnIndexOrThrow("Weight"));
                System.out.println(myText);
            }

            cursor.close();

            return weightList;
        }

    public int getWeightsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int weightsTotal = cursor.getCount();
        cursor.close();

        return weightsTotal;
    }

    public Cursor getWeight(String weight) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("select * from WeightsTable where Weight=" +weight, null);
    }



}

