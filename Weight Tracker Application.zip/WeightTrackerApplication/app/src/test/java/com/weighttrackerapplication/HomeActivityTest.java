package com.weighttrackerapplication;

import junit.framework.TestCase;

public class HomeActivityTest extends TestCase {

}